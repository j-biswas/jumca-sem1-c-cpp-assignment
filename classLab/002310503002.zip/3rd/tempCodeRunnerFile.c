
    fclose(ptr);